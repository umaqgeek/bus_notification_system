-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 11, 2015 at 04:01 PM
-- Server version: 6.0.4
-- PHP Version: 6.0.0-dev

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `multilevel`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `bus`
-- 

CREATE TABLE `bus` (
  `bus_id` int(11) NOT NULL,
  `bus_plate_no` varchar(10) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `bus`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `bus_driver`
-- 

CREATE TABLE `bus_driver` (
  `bus_driver_id` int(10) NOT NULL,
  `driver_id` int(10) NOT NULL,
  `bus_id` int(10) NOT NULL,
  PRIMARY KEY (`bus_driver_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `bus_driver`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `driver_location`
-- 

CREATE TABLE `driver_location` (
  `driver_location_id` int(10) NOT NULL,
  `qrcode_id` int(10) NOT NULL,
  `bus_driver_id` int(10) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`driver_location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `driver_location`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `geocode_cache`
-- 

CREATE TABLE `geocode_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lng` double NOT NULL,
  `lat` double NOT NULL,
  `query` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `geocode_cache`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `location`
-- 

CREATE TABLE `location` (
  `qrcode_id` varchar(50) NOT NULL,
  `location_name` varchar(50) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  PRIMARY KEY (`qrcode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `location`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `ic_no` int(20) NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `race` varchar(10) NOT NULL,
  `gender` int(2) NOT NULL,
  `address` varchar(30) NOT NULL,
  `religion` varchar(10) NOT NULL,
  `contact_no` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `level` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` VALUES (1, 11111, 'Amir Rashidi', '1', 0, '  taman melati', '1', 22222, 'amirrashidi91@yahoo.com', 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, 1);
INSERT INTO `user` VALUES (2, 22222, 'amarul samsudin', '1', 0, '  tttttttttttttttttttt', '1', 33333, 'amar@yahoo.com', 'driver', 'e2d45d57c7e2941b65c6ccd64af4223e', 2, 1);
INSERT INTO `user` VALUES (3, 33333, 'solehin', '1', 0, '  tmn nilam', '1', 55555, 'pass@yahoo.com', 'pass', '1a1dc91c907325c69271ddf0c944bc72', 3, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `ic_no` int(20) NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `race` varchar(10) NOT NULL,
  `gender` int(2) NOT NULL,
  `address` varchar(30) NOT NULL,
  `religion` varchar(10) NOT NULL,
  `contact_no` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (19, 22222, 'mazal', '2', 0, '  nnnnnnnnnnnnnnnnnnnnnnnnnnnn', '2', 0, 'mazalomania', 'mz@yahoo.com', 'e10adc3949ba59abbe56e057f20f883e', 0);
INSERT INTO `users` VALUES (17, 11111, 'amarul samsudin', '1', 0, '  mmmmmmmmmmm', '1', 22222, 'amar', 'amar@yahoo.com', '81dc9bdb52d04dc20036dbd8313ed055', 3);
INSERT INTO `users` VALUES (20, 33333, 'morgana', '3', 0, ' ooooooooooooooooooooooooooooo', '3', 444444, 'morgana', 'morgana@yahoo.com', 'fcea920f7412b5da7be0cf42b8c93759', 0);
INSERT INTO `users` VALUES (22, 11111, 'mirdas', '1', 0, '  zzzzzzzzzzzzzzzzzzzzzzzzzz', '1', 0, 'mirdas', 'mirdas@yahoo.con', '099ebea48ea9666a7da2177267983138', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `user_type`
-- 

CREATE TABLE `user_type` (
  `ut_id` int(11) NOT NULL,
  `ut_desc` varchar(30) NOT NULL,
  PRIMARY KEY (`ut_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `user_type`
-- 

INSERT INTO `user_type` VALUES (1, 'administrator');
INSERT INTO `user_type` VALUES (2, 'driver');
INSERT INTO `user_type` VALUES (3, 'passenger');
